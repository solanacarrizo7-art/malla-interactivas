
function toggle(element) {
    element.classList.toggle('tachada');
}
